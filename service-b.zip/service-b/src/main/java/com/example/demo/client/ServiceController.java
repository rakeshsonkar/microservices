package com.example.demo.client;

import java.io.IOException;
import java.util.Set;

import javax.ws.rs.POST;
import javax.ws.rs.Path;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.networknt.schema.JsonSchema;
import com.networknt.schema.JsonSchemaFactory;
import com.networknt.schema.SpecVersion;
import com.networknt.schema.ValidationMessage;

@Path("/client/service")
public class ServiceController {

	@POST
	public String doSomething(String parameter) throws IOException {

		//String inputJson = "{\"id\": 1,\"name\": \"Lampshade\"}";
		ObjectMapper mapper = new ObjectMapper();
		JsonSchemaFactory factory = JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V4);
		JsonSchema jsonSchema = factory.getSchema(ServiceController.class.getResourceAsStream("/schema1.json"));
		//JsonNode jsonNode = mapper.readTree(ServiceController.class.getResourceAsStream("/product_invalid.json"));
		JsonNode jsonNode = mapper.readTree(parameter);
		
		Set<ValidationMessage> errors = jsonSchema.validate(jsonNode);
		System.out.println(errors);
		return String.valueOf(errors);
	}
}
